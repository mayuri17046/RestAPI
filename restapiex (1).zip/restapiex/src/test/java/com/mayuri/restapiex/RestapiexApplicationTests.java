package com.mayuri.restapiex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestapiexApplicationTests {

	@Test
	void contextLoads() {
	}

}
